sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("sap.ui5.northwind.controller.View1", {
            onInit: function () {
                

                // oModel = this.getView().getModel();
               

            },

            onBeforeRendering : function(){

                var oTable = this.getView().byId("idList");
                var oModel = this.getView().getModel();
                var oMetaData = oModel.getServiceMetadata().dataServices;
                
                var iLength = oMetaData.schema[0].entityType[3].property.length;
                var sGetName = oMetaData.schema[0].entityType[3];
                
                for( var i = 0; i < iLength - 10; i++ ){

                    var oColumn = new sap.m.Column("col" + i, {
                                width: "1em",
                                header: new sap.m.Label({
                                        text: sGetName.property[i].name
                                })
                    });
                    oTable.addColumn(oColumn);
                }

                var oCell = [];
                for( var i = 0; i < iLength - 10 ; i++ ){
                     var sBindingPath =  sGetName.property[i].name;
                            
                     var cell = new sap.m.Text({
                                        text : "{"+sBindingPath+"}"
                            }); 

                        oCell.push(cell);
                }

                var aColList = new sap.m.ColumnListItem("aColListID",{
                    cells: oCell
                });

                oTable.bindItems("/Employees", aColList);
                    
            },

           
        });
    });
