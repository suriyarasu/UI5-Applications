sap.ui.define([
	"sapui5/northwind/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
