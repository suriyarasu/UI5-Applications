/* global QUnit */

sap.ui.require(["sap/ui5/northwind/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
